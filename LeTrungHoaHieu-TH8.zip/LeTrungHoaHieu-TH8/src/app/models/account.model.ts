export interface Account {
  username: string;
  password: string;
  balance: number;
}
