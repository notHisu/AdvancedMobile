export const environment = {
  production: true,
  googleMapsApiKey: 'AIzaSyB9oMYr43BaBIvXWgHKxwAHY98NOCKW7b8',
};
